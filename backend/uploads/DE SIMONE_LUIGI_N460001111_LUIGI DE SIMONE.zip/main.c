#include <stdio.h>
#include <stdlib.h> //definizione di malloc, realloc, calloc e free


// Inserimento utilizzando la malloc per allocare 
// il nuovo vettore, contentente il vettore di partenza 
// più l'elemento da inserire
// La funzione ritorna il puntatore al nuovo vettore se 
// l'allocazione riesce, altrimenti ritorna il puntatore 
// al vettore di partenza

int *inserisci_v1(int *old_vector, int *riemp, int valore_da_aggiungere);

int main() {

    // array inizialmente grande 50

    //int *arr_dinamico = malloc(sizeof(int)* 50);


    int *arr_dinamico = malloc(sizeof(int));

    int riemp = 0;

    // creare una funzione che inserisca un elemento 
    // nuovo all'interno dell'array

    arr_dinamico = inserisci_v1(arr_dinamico, 
                                &riemp, 
                                100);

    return 0;

}

void inserisci_v2_con_malloc(int **old_vector, int *riemp, int valore_da_aggiungere);

int *inserisci_v1(int *old_vector, int *riemp, int valore_da_aggiungere){

    // allocare uno spazio nuovo atto a contenere
    // tutto il vecchio array + il nuovo elemento da inserire

    // VINCOLO: USARE SOLO LA MALLOC
    printf("sizeof(old_vector): %lu\n", sizeof(old_vector));

    int *new_vector = malloc( sizeof(int) * ( (*riemp) +1 ));

    //controllare che la malloc restituisca un puntatore valido!!!!
    if (new_vector != NULL){

        // copio il vecchio vettore nel nuovo e poi copio in ultima posizione
        // il nuovo elemento

        for (int i=0; i<*riemp; i++){

            *(new_vector + i) = *(old_vector + i); /// copio old_vector[i] in new_vector[i]
            //new_vector[i] = old_vector[i];

        }
        // copio il nuovo elemento da aggiungere alla posizione *riemp

        *(new_vector + *riemp) = valore_da_aggiungere;

        // aggiornare il riempimento
        (*riemp)++;

        // devo deallocare old_vector
        free(old_vector); // se non lo faccio lascio un buco nel main...

        return new_vector;

    } else { //la malloc fallisce => NON HO ALLOCATO NULLA => NON DEVO FARE LA FREE di new_vector

        printf("inserimento fallito\n");
        new_vector = old_vector;
        return new_vector;
    }
}
