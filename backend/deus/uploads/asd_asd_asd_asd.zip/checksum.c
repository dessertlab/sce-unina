#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/msg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <errno.h>

#include "header.h"

void checksum(int queue_filter_checksum, int queue_checksum_visual){

        int ret, i, j, checksum;
        message mess;

        for (j=0; j<NUM_MESSAGES; j++){
                printf("[checksum] Ricevo dal processo Filter...\n");
                //c'è il rischio che venga schedulato prima dell'invio e quindi si mangia dei cicli che potrebbero essere utili
                //per evitare o si mette una sleep qui oppure bisogna usare una receive bloccante ma bisogna cambiare il for
                ret = msgrcv(queue_filter_checksum, &mess, sizeof(message)-sizeof(long), MSG_TYPE, IPC_NOWAIT);/* TODO: ricevere il messaggio dal processo filter */
            
                if(ret<0) {
                        if (errno == ENOMSG){
                                printf("Non ci sono più messaggi da ricevere dal processo filter...exit!\n");
                                break;
                        }
                        else{
                                perror("ERROR!!!");
                                exit(-1);
                        }
                }

                i = 0; 
                checksum = 0; 
                while(mess.stringa[i] != '\0'){

                        checksum = checksum+ (int) mess.stringa[i]; 
                        i++;
                }
                checksum = checksum + mess.array[0]; 
                checksum = checksum + mess.array[1]; 

                mess.var = checksum; 
                msgsnd(queue_checksum_visual, &mess, sizeof(message)-sizeof(long), 0);
                /* TODO: Calcolare la checksum e inviarla al visualizzatore  */
                
                printf("[checksum] Invio messaggio di CHECKSUM al Visualizzatore...\n");
        }
        
        exit(0);
}

